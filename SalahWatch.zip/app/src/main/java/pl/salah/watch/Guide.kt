package pl.salah.watch

/** Step-by-step prayer guide, generated per prayer from its number of rakahs. */

enum class Pose { STAND, HANDS_UP, FOLDED, BOW, PROSTRATE, SIT, SIT_SALAM }

data class Recitation(
    val arabic: String,
    val translit: String,
    val meaning: String,
    val repeat: Int = 1,
)

data class Step(
    val rakah: Int,
    val title: String,
    val instruction: String,
    val pose: Pose,
    val recitations: List<Recitation>,
    val seconds: Int,          // time used by autoplay
)

private object PrayerRecitations {
    val takbir = Recitation("اللَّهُ أَكْبَرُ", "Allaahu akbar", "Allah jest Największy!")
    val subhanaka = Recitation(
        "سُبْحَانَكَ اللَّهُمَّ وَبِحَمْدِكَ، وَتَبَارَكَ اسْمُكَ، وَتَعَالَى جَدُّكَ، وَلَا إِلَهَ غَيْرُكَ",
        "Subhaanaka llaahumma wa bihamdika, wa tabaaraka smuka, wa ta'aalaa jadduka, wa laa ilaaha ghayruk",
        "Chwała Tobie, o Allahu, i Tobie cześć. Błogosławione jest Twoje imię, wywyższony Twój majestat i nie ma boga poza Tobą.",
    )
    val taawwudh = Recitation(
        "أَعُوذُ بِاللَّهِ مِنَ الشَّيْطَانِ الرَّجِيمِ\nبِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
        "A'uudhu billaahi mina sh-shaytaani r-rajiim. Bismillaahi r-rahmaani r-rahiim",
        "Szukam u Allaha schronienia przed szatanem przeklętym. W imię Allaha, Miłosiernego, Litościwego.",
    )
    val basmala = Recitation(
        "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ",
        "Bismillaahi r-rahmaani r-rahiim",
        "W imię Allaha, Miłosiernego, Litościwego.",
    )
    val fatiha = Recitation(
        "الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ ۝ الرَّحْمَٰنِ الرَّحِيمِ ۝ مَالِكِ يَوْمِ الدِّينِ ۝ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ۝ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ ۝ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ ۝ آمِين",
        "Al-hamdu lillaahi rabbi l-'aalamiin. Ar-rahmaani r-rahiim. Maaliki yawmi d-diin. Iyyaaka na'budu wa iyyaaka nasta'iin. Ihdina s-siraata l-mustaqiim. Siraata lladhiina an'amta 'alayhim, ghayri l-maghduubi 'alayhim wa la d-daalliin. Aamiin",
        "Chwała Allahowi, Panu światów, Miłosiernemu, Litościwemu, Władcy Dnia Sądu. Tylko Tobie służymy i tylko Ciebie prosimy o pomoc. Prowadź nas drogą prostą — drogą tych, których obdarzyłeś łaską, nie tych, na których jest gniew, ani nie tych, którzy błądzą. Amen.",
    )
    val ikhlas = Recitation(
        "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nقُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ",
        "Bismillaahi r-rahmaani r-rahiim. Qul huwa llaahu ahad. Allaahu s-samad. Lam yalid wa lam yuulad. Wa lam yakun lahu kufuwan ahad",
        "Sura Al-Ikhlas (lub inna krótka sura): Powiedz: On, Allah, jest Jeden. Allah — Wieczny. Nie zrodził i nie został zrodzony. I nikt nie jest Mu równy.",
    )
    val ruku = Recitation("سُبْحَانَ رَبِّيَ الْعَظِيمِ", "Subhaana rabbiya l-'adhiim", "Chwała mojemu Panu, Wielkiemu.", 3)
    val rise = Recitation(
        "سَمِعَ اللَّهُ لِمَنْ حَمِدَهُ\nرَبَّنَا وَلَكَ الْحَمْدُ",
        "Sami'a llaahu liman hamidah. Rabbanaa wa laka l-hamd",
        "Allah słyszy tego, kto Go wychwala. Panie nasz, Tobie chwała.",
    )
    val sujud = Recitation("سُبْحَانَ رَبِّيَ الْأَعْلَى", "Subhaana rabbiya l-a'laa", "Chwała mojemu Panu, Najwyższemu.", 3)
    val between = Recitation("رَبِّ اغْفِرْ لِي", "Rabbi ghfir lii", "Panie mój, przebacz mi.", 2)
    val tashahhud = Recitation(
        "التَّحِيَّاتُ لِلَّهِ وَالصَّلَوَاتُ وَالطَّيِّبَاتُ، السَّلَامُ عَلَيْكَ أَيُّهَا النَّبِيُّ وَرَحْمَةُ اللَّهِ وَبَرَكَاتُهُ، السَّلَامُ عَلَيْنَا وَعَلَى عِبَادِ اللَّهِ الصَّالِحِينَ، أَشْهَدُ أَنْ لَا إِلَهَ إِلَّا اللَّهُ وَأَشْهَدُ أَنَّ مُحَمَّدًا عَبْدُهُ وَرَسُولُهُ",
        "At-tahiyyaatu lillaahi wa s-salawaatu wa t-tayyibaat. As-salaamu 'alayka ayyuha n-nabiyyu wa rahmatu llaahi wa barakaatuh. As-salaamu 'alaynaa wa 'alaa 'ibaadi llaahi s-saalihiin. Ash-hadu an laa ilaaha illa llaah, wa ash-hadu anna Muhammadan 'abduhu wa rasuuluh",
        "Pozdrowienia, modlitwy i dobre słowa należą do Allaha. Pokój z tobą, o Proroku, oraz miłosierdzie Allaha i Jego błogosławieństwo. Pokój z nami i z prawymi sługami Allaha. Świadczę, że nie ma boga poza Allahem, i świadczę, że Muhammad jest Jego sługą i wysłannikiem.",
    )
    val salawat = Recitation(
        "اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ، كَمَا صَلَّيْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ، إِنَّكَ حَمِيدٌ مَجِيدٌ، اللَّهُمَّ بَارِكْ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ، كَمَا بَارَكْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ، إِنَّكَ حَمِيدٌ مَجِيدٌ",
        "Allaahumma salli 'alaa Muhammadin wa 'alaa aali Muhammad, kamaa sallayta 'alaa Ibraahiima wa 'alaa aali Ibraahiim, innaka hamiidun majiid. Allaahumma baarik 'alaa Muhammadin wa 'alaa aali Muhammad, kamaa baarakta 'alaa Ibraahiima wa 'alaa aali Ibraahiim, innaka hamiidun majiid",
        "O Allahu, obdarz łaską Muhammada i rodzinę Muhammada, tak jak obdarzyłeś Ibrahima i rodzinę Ibrahima — zaprawdę Ty jesteś Godny chwały, Chwalebny. O Allahu, pobłogosław Muhammada i rodzinę Muhammada, tak jak pobłogosławiłeś Ibrahima i rodzinę Ibrahima — zaprawdę Ty jesteś Godny chwały, Chwalebny.",
    )
    val salam = Recitation(
        "السَّلَامُ عَلَيْكُمْ وَرَحْمَةُ اللَّهِ",
        "As-salaamu 'alaykum wa rahmatu llaah",
        "Pokój z wami i miłosierdzie Allaha. (najpierw w prawo, potem w lewo)",
        2,
    )
}

object Guide {
    fun stepsFor(prayer: Prayer): List<Step> {
        val n = prayer.rakahs
        val s = mutableListOf<Step>()
        for (r in 1..n) {
            if (r == 1) {
                s += Step(r, "Intencja i Takbir", "Stań twarzą w stronę Kibli. W sercu postanów odmówić ${prayer.label} (${n} rak'ah). Unieś dłonie do uszu i powiedz:", Pose.HANDS_UP, listOf(PrayerRecitations.takbir), 4)
                s += Step(r, "Du'a otwarcia (Subhanaka)", "Połóż prawą dłoń na lewej na piersi i cicho powiedz:", Pose.FOLDED, listOf(PrayerRecitations.subhanaka), 10)
            } else {
                s += Step(r, "Wstań", "Wstań z Takbirem i złóż dłonie na piersi.", Pose.FOLDED, listOf(PrayerRecitations.takbir), 4)
            }
            if (r == 1) s += Step(r, "Ta'awwudh i Basmala", "Cicho powiedz:", Pose.FOLDED, listOf(PrayerRecitations.taawwudh), 7)
            else s += Step(r, "Basmala", "Cicho powiedz:", Pose.FOLDED, listOf(PrayerRecitations.basmala), 4)
            s += Step(r, "Al-Fatiha", "Wyrecytuj surę Al-Fatiha:", Pose.FOLDED, listOf(PrayerRecitations.fatiha), 35)
            if (r <= 2) s += Step(r, "Krótka sura", "Po Al-Fatiha wyrecytuj krótką surę, np.:", Pose.FOLDED, listOf(PrayerRecitations.ikhlas), 14)
            s += Step(r, "Ruku' (skłon)", "Z Takbirem pochyl się, dłonie na kolanach, plecy proste. Powiedz 3×:", Pose.BOW, listOf(PrayerRecitations.takbir, PrayerRecitations.ruku), 9)
            s += Step(r, "Powstanie z Ruku'", "Wyprostuj się, mówiąc:", Pose.STAND, listOf(PrayerRecitations.rise), 6)
            s += Step(r, "Sujud (pokłon) 1", "Z Takbirem uklęknij i dotknij ziemi czołem, nosem, dłońmi, kolanami i palcami stóp. Powiedz 3×:", Pose.PROSTRATE, listOf(PrayerRecitations.takbir, PrayerRecitations.sujud), 9)
            s += Step(r, "Siad między pokłonami", "Z Takbirem usiądź na chwilę i powiedz:", Pose.SIT, listOf(PrayerRecitations.takbir, PrayerRecitations.between), 6)
            s += Step(r, "Sujud (pokłon) 2", "Z Takbirem wykonaj drugi pokłon. Powiedz 3×:", Pose.PROSTRATE, listOf(PrayerRecitations.takbir, PrayerRecitations.sujud), 9)

            val last = r == n
            if (r == 2 && !last) {
                s += Step(r, "Pierwszy Tashahhud", "Usiądź z Takbirem. Unieś palec wskazujący prawej dłoni przy świadectwie. Potem wstań do 3. rak'ah.", Pose.SIT, listOf(PrayerRecitations.takbir, PrayerRecitations.tashahhud), 22)
            }
            if (last) {
                s += Step(r, "Ostatni Tashahhud", "Usiądź z Takbirem i powiedz:", Pose.SIT, listOf(PrayerRecitations.takbir, PrayerRecitations.tashahhud), 22)
                s += Step(r, "Salawat Ibrahimiyya", "Następnie powiedz:", Pose.SIT, listOf(PrayerRecitations.salawat), 22)
                s += Step(r, "Taslim (zakończenie)", "Obróć głowę w prawo, a potem w lewo, mówiąc za każdym razem:", Pose.SIT_SALAM, listOf(PrayerRecitations.salam), 7)
            }
        }
        return s
    }
}
