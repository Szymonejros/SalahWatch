package pl.salah.watch

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.wear.compose.foundation.lazy.AutoCenteringParams
import androidx.wear.compose.foundation.lazy.ScalingLazyColumn
import androidx.wear.compose.foundation.lazy.rememberScalingLazyListState
import androidx.wear.compose.material.*
import kotlinx.coroutines.delay
import java.util.Calendar

// ---------- helpers ----------

private fun nowHours(): Double {
    val c = Calendar.getInstance()
    return c.get(Calendar.HOUR_OF_DAY) + c.get(Calendar.MINUTE) / 60.0 + c.get(Calendar.SECOND) / 3600.0
}

private fun untilText(hours: Double): String {
    val m = (hours * 60).toInt().coerceAtLeast(0)
    return if (m >= 60) "za ${m / 60} h ${m % 60} min" else "za $m min"
}

@Suppress("DEPRECATION")
fun vibrate(ctx: Context, ms: Long = 120) {
    val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
    v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
}

@Composable
private fun greenChipColors() = ChipDefaults.chipColors(
    backgroundColor = Green.Card, contentColor = Green.Pale,
    secondaryContentColor = Green.Muted, iconColor = Green.Light,
)

// ---------- Home ----------

@Composable
fun HomeScreen(store: Store, onPrayer: (Prayer) -> Unit, onLocation: () -> Unit, onSettings: () -> Unit) {
    var now by remember { mutableDoubleStateOf(nowHours()) }
    LaunchedEffect(Unit) { while (true) { delay(20_000); now = nowHours() } }

    val today = remember(store.lat, store.lng, store.method, store.hanafi, now.toInt()) {
        if (store.hasLocation) PrayerTimes.compute(store.lat, store.lng, Calendar.getInstance(), store.method, store.hanafi) else null
    }
    // (prayer, hours until, clock time)
    val next: Triple<Prayer, Double, Double>? = today?.let { t ->
        Prayer.entries.firstOrNull { t.of(it) > now }?.let { Triple(it, t.of(it) - now, t.of(it)) }
            ?: run {
                val tomorrow = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
                val f = PrayerTimes.compute(store.lat, store.lng, tomorrow, store.method, store.hanafi).fajr
                Triple(Prayer.FAJR, 24 - now + f, f)
            }
    }

    // Before Fajr, Isha from the previous day remains the current prayer.
    val current = today?.let { t -> Prayer.entries.lastOrNull { t.of(it) <= now } ?: Prayer.ISHA }

    val listState = rememberScalingLazyListState()
    Scaffold(timeText = { TimeText() }, positionIndicator = { PositionIndicator(listState) }) {
        ScalingLazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            autoCentering = AutoCenteringParams(itemIndex = 1),
        ) {
            item {
                CompactChip(
                    onClick = onLocation,
                    label = { Text(store.locationName ?: "Brak lokalizacji", maxLines = 1) },
                    icon = { Icon(Icons.Default.LocationOn, null, Modifier.size(16.dp)) },
                    colors = greenChipColors(),
                )
            }
            item {
                if (next == null) {
                    Column(
                        Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text("Nie wybrano lokalizacji", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        Text("Wybierz miasto, żeby pokazać godziny modlitw.", fontSize = 12.sp, color = Green.Muted, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(6.dp))
                        Button(onClick = onLocation, modifier = Modifier.width(120.dp).height(36.dp), colors = ButtonDefaults.buttonColors(backgroundColor = Green.Light)) {
                            Text("Ustaw", color = Green.Bg)
                        }
                    }
                } else {
                    Column(
                        Modifier.fillMaxWidth().background(Green.Dark, RoundedCornerShape(24.dp)).padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text("Następna", fontSize = 11.sp, color = Green.Muted)
                        Text("${next.first.label} ${PrayerTimes.format(next.third)}", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Green.Pale)
                        Text(untilText(next.second), fontSize = 12.sp, color = Green.Light)
                    }
                }
            }
            items(Prayer.entries.size) { i ->
                val p = Prayer.entries[i]
                val isCurrent = current == p
                Chip(
                    onClick = { onPrayer(p) },
                    label = { Text(p.label, fontWeight = FontWeight.Bold) },
                    secondaryLabel = {
                        Text("${p.rakahs} rak'ah" + (today?.let { " · ${PrayerTimes.format(it.of(p))}" } ?: ""))
                    },
                    icon = { Text(prayerGlyph(p), fontSize = 18.sp) },
                    colors = if (isCurrent) ChipDefaults.chipColors(
                        backgroundColor = Green.Light, contentColor = Green.Bg, secondaryContentColor = Green.Dark,
                    ) else greenChipColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            item {
                Chip(
                    onClick = onSettings,
                    label = { Text("Ustawienia") },
                    icon = { Icon(Icons.Default.Settings, null) },
                    colors = ChipDefaults.secondaryChipColors(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}

private fun prayerGlyph(p: Prayer) = when (p) {
    Prayer.FAJR -> "🌅"; Prayer.DHUHR -> "☀️"; Prayer.ASR -> "🌤"; Prayer.MAGHRIB -> "🌇"; Prayer.ISHA -> "🌙"
}

// ---------- Guide ----------

@Composable
fun GuideScreen(store: Store, prayer: Prayer) {
    val ctx = LocalContext.current
    val activity = ctx as? MainActivity
    val steps = remember(prayer) { Guide.stepsFor(prayer) }
    var index by rememberSaveable { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    val step = steps[index]
    val listState = rememberScalingLazyListState()

    // keep screen on while the guide is open
    val view = LocalView.current
    DisposableEffect(Unit) { view.keepScreenOn = true; onDispose { view.keepScreenOn = false; activity?.stopSpeaking() } }

    LaunchedEffect(index) { listState.scrollToItem(0) }

    // Autoplay: wait for the step's duration, vibrate, go to next step
    LaunchedEffect(playing, index) {
        if (!playing) return@LaunchedEffect
        delay((step.seconds * 1000 / store.speed).toLong())
        if (index < steps.lastIndex) {
            index++
            if (store.vibrate) vibrate(ctx)
        } else {
            playing = false
            if (store.vibrate) vibrate(ctx, 500)
        }
    }

    Scaffold(
        timeText = { TimeText() },
        positionIndicator = { PositionIndicator(listState) },
    ) {
        CircularProgressIndicator(
            progress = (index + 1f) / steps.size,
            modifier = Modifier.fillMaxSize().padding(2.dp),
            startAngle = 300f, endAngle = 240f,
            indicatorColor = Green.Light, trackColor = Green.Card, strokeWidth = 4.dp,
        )
        ScalingLazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp),
            autoCentering = AutoCenteringParams(itemIndex = 0),
        ) {
            item {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("${prayer.label} · Rak'ah ${step.rakah}/${prayer.rakahs}", fontSize = 11.sp, color = Green.Muted)
                    PoseFigure(step.pose, Modifier.size(64.dp))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    CompactButton(
                        onClick = { if (index > 0) { index--; playing = false } },
                        enabled = index > 0,
                        colors = ButtonDefaults.secondaryButtonColors(),
                    ) { Icon(Icons.Default.KeyboardArrowLeft, "Wstecz") }
                    Button(
                        onClick = { playing = !playing; if (playing && index == steps.lastIndex) index = 0 },
                        modifier = Modifier.size(44.dp),
                        colors = ButtonDefaults.buttonColors(backgroundColor = Green.Light),
                    ) {
                        if (playing) Text("❚❚", color = Green.Bg, fontWeight = FontWeight.Bold)
                        else Icon(Icons.Default.PlayArrow, "Autoodtwarzanie", tint = Green.Bg)
                    }
                    CompactButton(
                        onClick = { if (index < steps.lastIndex) { index++; playing = false } },
                        enabled = index < steps.lastIndex,
                        colors = ButtonDefaults.secondaryButtonColors(),
                    ) { Icon(Icons.Default.KeyboardArrowRight, "Dalej") }
                }
            }
            item {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(step.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, textAlign = TextAlign.Center, color = Green.Pale)
                    Text(step.instruction, fontSize = 12.sp, textAlign = TextAlign.Center, color = Green.Muted)
                }
            }
            step.recitations.forEach { r ->
                item {
                    Column(
                        Modifier.fillMaxWidth().background(Green.Card, RoundedCornerShape(18.dp)).padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            r.arabic,
                            style = TextStyle(fontSize = 18.sp, textDirection = TextDirection.Rtl, textAlign = TextAlign.Center, color = Green.Pale),
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            r.translit.uppercase() + if (r.repeat > 1) "  ×${r.repeat}" else "",
                            fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Green.Light, textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(r.meaning, fontSize = 11.sp, color = Green.Muted, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(4.dp))
                        CompactChip(
                            onClick = {
                                if (activity?.ttsReady == true) activity.speak(r.arabic)
                                else Toast.makeText(ctx, "Brak głosu arabskiego w zegarku", Toast.LENGTH_SHORT).show()
                            },
                            label = { Text("🔊 Odsłuchaj", fontSize = 11.sp) },
                            colors = ChipDefaults.secondaryChipColors(),
                        )
                    }
                }
            }
            item { Text("Krok ${index + 1} z ${steps.size}", fontSize = 11.sp, color = Green.Muted) }
        }
    }
}

// ---------- Location ----------

@Composable
fun LocationScreen(store: Store, onDone: () -> Unit) {
    val ctx = LocalContext.current
    var searching by remember { mutableStateOf(false) }

    fun useGps() {
        searching = true
        requestLocation(ctx) { loc ->
            android.os.Handler(android.os.Looper.getMainLooper()).post {
                searching = false
                if (loc != null) {
                    store.setLocation("GPS %.2f, %.2f".format(loc.latitude, loc.longitude), loc.latitude, loc.longitude)
                    onDone()
                } else Toast.makeText(ctx, "Nie udało się ustalić pozycji", Toast.LENGTH_SHORT).show()
            }
        }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.any { it }) useGps() else Toast.makeText(ctx, "Brak zgody na lokalizację", Toast.LENGTH_SHORT).show()
    }

    val listState = rememberScalingLazyListState()
    Scaffold(timeText = { TimeText() }, positionIndicator = { PositionIndicator(listState) }) {
        ScalingLazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
            item { ListHeader { Text("Lokalizacja") } }
            item {
                Chip(
                    onClick = {
                        val granted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                        if (granted) useGps() else launcher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                    },
                    label = { Text(if (searching) "Szukam…" else "Użyj GPS") },
                    icon = { Icon(Icons.Default.LocationOn, null) },
                    colors = ChipDefaults.primaryChipColors(backgroundColor = Green.Light, contentColor = Green.Bg, iconColor = Green.Bg),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            CITIES.forEach { c ->
                item {
                    Chip(
                        onClick = { store.setLocation(c.name, c.lat, c.lng); onDone() },
                        label = { Text(c.name) },
                        colors = greenChipColors(),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            }
        }
    }
}

// ---------- Settings ----------

@Composable
fun SettingsScreen(store: Store, onLocation: () -> Unit) {
    val listState = rememberScalingLazyListState()
    Scaffold(timeText = { TimeText() }, positionIndicator = { PositionIndicator(listState) }) {
        ScalingLazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
            item { ListHeader { Text("Ustawienia") } }
            item {
                Chip(onClick = onLocation, label = { Text("Lokalizacja") },
                    secondaryLabel = { Text(store.locationName ?: "brak") },
                    colors = greenChipColors(), modifier = Modifier.fillMaxWidth())
            }
            item {
                Chip(onClick = { store.cycleMethod() }, label = { Text("Metoda obliczeń") },
                    secondaryLabel = { Text(store.method.label) },
                    colors = greenChipColors(), modifier = Modifier.fillMaxWidth())
            }
            item {
                ToggleChip(
                    checked = store.hanafi, onCheckedChange = { store.toggleHanafi() },
                    label = { Text("Asr – Hanafi") },
                    secondaryLabel = { Text(if (store.hanafi) "Cień ×2" else "Standard (cień ×1)") },
                    toggleControl = { Switch(checked = store.hanafi) },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            item {
                Chip(onClick = { store.cycleSpeed() }, label = { Text("Tempo autoodtwarzania") },
                    secondaryLabel = { Text("×${store.speed}") },
                    colors = greenChipColors(), modifier = Modifier.fillMaxWidth())
            }
            item {
                ToggleChip(
                    checked = store.vibrate, onCheckedChange = { store.toggleVibrate() },
                    label = { Text("Wibracja przy kroku") },
                    toggleControl = { Switch(checked = store.vibrate) },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        }
    }
}
