package pl.salah.watch

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.wear.compose.material.MaterialTheme
import androidx.wear.compose.material.Colors
import androidx.wear.compose.navigation.SwipeDismissableNavHost
import androidx.wear.compose.navigation.composable
import androidx.wear.compose.navigation.rememberSwipeDismissableNavController
import androidx.compose.ui.graphics.Color
import java.util.Locale

object Green {
    val Bg = Color(0xFF0E1A11)
    val Card = Color(0xFF1C2E20)
    val Dark = Color(0xFF2F3E32)
    val Light = Color(0xFFA5CF9E)
    val Pale = Color(0xFFE8F3E5)
    val Muted = Color(0xFF8FA98B)
}

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    var ttsReady = false; private set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ar"))
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
        val store = Store(this)
        setContent { App(store) }
    }

    fun speak(text: String) { if (ttsReady) tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "salah") }
    fun stopSpeaking() { tts?.stop() }

    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@Composable
fun App(store: Store) {
    val nav = rememberSwipeDismissableNavController()
    MaterialTheme(
        colors = Colors(
            primary = Green.Light, onPrimary = Green.Bg,
            secondary = Green.Dark, onSecondary = Green.Pale,
            background = Color.Black, surface = Green.Card, onSurface = Green.Pale,
        )
    ) {
        SwipeDismissableNavHost(navController = nav, startDestination = "home") {
            composable("home") {
                HomeScreen(
                    store,
                    onPrayer = { nav.navigate("guide/${it.name}") },
                    onLocation = { nav.navigate("location") },
                    onSettings = { nav.navigate("settings") },
                )
            }
            composable("guide/{p}") { entry ->
                val p = Prayer.valueOf(entry.arguments?.getString("p") ?: Prayer.FAJR.name)
                GuideScreen(store, p)
            }
            composable("location") { LocationScreen(store, onDone = { nav.popBackStack() }) }
            composable("settings") { SettingsScreen(store, onLocation = { nav.navigate("location") }) }
        }
    }
}
