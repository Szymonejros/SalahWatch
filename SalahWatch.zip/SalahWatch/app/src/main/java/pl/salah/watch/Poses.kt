package pl.salah.watch

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke

/** Simple side-view figure for each prayer position (drawn in a 100×100 box). */
@Composable
fun PoseFigure(pose: Pose, modifier: Modifier = Modifier, color: Color = Green.Light) {
    Canvas(modifier) {
        val s = size.minDimension / 100f
        val ox = (size.width - 100 * s) / 2
        val oy = (size.height - 100 * s) / 2
        fun p(x: Float, y: Float) = Offset(ox + x * s, oy + y * s)
        val stroke = Stroke(width = 6 * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun line(vararg pts: Pair<Float, Float>) {
            val path = Path().apply {
                moveTo(p(pts[0].first, pts[0].second).x, p(pts[0].first, pts[0].second).y)
                pts.drop(1).forEach { lineTo(p(it.first, it.second).x, p(it.first, it.second).y) }
            }
            drawPath(path, color, style = stroke)
        }
        fun head(x: Float, y: Float) = drawCircle(color, 7.5f * s, p(x, y))

        // ground
        drawLine(color.copy(alpha = 0.35f), p(8f, 96f), p(92f, 96f), 3 * s, StrokeCap.Round)

        when (pose) {
            Pose.STAND -> { head(50f, 14f); line(50f to 23f, 50f to 58f, 50f to 94f); line(50f to 28f, 50f to 56f) }
            Pose.HANDS_UP -> { head(50f, 14f); line(50f to 23f, 50f to 58f, 50f to 94f); line(50f to 29f, 58f to 24f, 57f to 10f) }
            Pose.FOLDED -> { head(50f, 14f); line(50f to 23f, 50f to 58f, 50f to 94f); line(50f to 29f, 58f to 40f, 51f to 44f) }
            Pose.BOW -> { head(80f, 50f); line(36f to 94f, 36f to 54f, 72f to 52f); line(66f to 53f, 56f to 74f) }
            Pose.PROSTRATE -> {
                head(80f, 87f)
                line(18f to 94f, 44f to 94f, 38f to 64f, 72f to 84f)   // feet→knee→hip→shoulders
                line(66f to 81f, 70f to 94f, 82f to 94f)               // arm, palm on ground
            }
            Pose.SIT, Pose.SIT_SALAM -> {
                head(38f, 37f)
                line(30f to 94f, 64f to 94f, 34f to 80f, 37f to 46f)   // shin→knee→hip→shoulders
                line(37f to 52f, 50f to 70f, 60f to 84f)               // hand on thigh
                if (pose == Pose.SIT_SALAM) {
                    line(52f to 30f, 64f to 30f); line(59f to 25f, 64f to 30f, 59f to 35f)
                    line(24f to 30f, 12f to 30f); line(17f to 25f, 12f to 30f, 17f to 35f)
                }
            }
        }
    }
}
