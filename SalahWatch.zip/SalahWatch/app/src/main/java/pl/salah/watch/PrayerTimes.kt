package pl.salah.watch

import java.util.Calendar
import java.util.TimeZone
import kotlin.math.*

/** Prayer-time calculation (offline, astronomical formulas in the style of praytimes.org). */

enum class Method(val label: String, val fajrAngle: Double, val ishaAngle: Double?, val ishaMinutes: Int?) {
    MWL("Muslim World League", 18.0, 17.0, null),
    ISNA("ISNA (Ameryka Płn.)", 15.0, 15.0, null),
    EGYPT("Egipt", 19.5, 17.5, null),
    MAKKAH("Umm al-Qura (Mekka)", 18.5, null, 90),
    KARACHI("Karaczi", 18.0, 18.0, null),
}

enum class Prayer(val label: String, val rakahs: Int) {
    FAJR("Fajr", 2),
    DHUHR("Dhuhr", 4),
    ASR("Asr", 4),
    MAGHRIB("Maghrib", 3),
    ISHA("Isha", 4),
}

data class DayTimes(
    val fajr: Double, val sunrise: Double, val dhuhr: Double,
    val asr: Double, val maghrib: Double, val isha: Double,
) {
    fun of(p: Prayer) = when (p) {
        Prayer.FAJR -> fajr; Prayer.DHUHR -> dhuhr; Prayer.ASR -> asr
        Prayer.MAGHRIB -> maghrib; Prayer.ISHA -> isha
    }
}

object PrayerTimes {
    private fun dsin(d: Double) = sin(Math.toRadians(d))
    private fun dcos(d: Double) = cos(Math.toRadians(d))
    private fun dtan(d: Double) = tan(Math.toRadians(d))
    private fun darcsin(x: Double) = Math.toDegrees(asin(x))
    private fun darccos(x: Double) = Math.toDegrees(acos(x))
    private fun darctan2(y: Double, x: Double) = Math.toDegrees(atan2(y, x))
    private fun darccot(x: Double) = Math.toDegrees(atan(1 / x))
    private fun fix(a: Double, b: Double): Double { val r = a - b * floor(a / b); return if (r < 0) r + b else r }
    private fun fixAngle(a: Double) = fix(a, 360.0)
    private fun fixHour(a: Double) = fix(a, 24.0)

    private fun julian(y: Int, m: Int, d: Int): Double {
        var yy = y; var mm = m
        if (mm <= 2) { yy -= 1; mm += 12 }
        val a = floor(yy / 100.0)
        val b = 2 - a + floor(a / 4)
        return floor(365.25 * (yy + 4716)) + floor(30.6001 * (mm + 1)) + d + b - 1524.5
    }

    /** returns Pair(declination, equation of time) */
    private fun sunPosition(jd: Double): Pair<Double, Double> {
        val d = jd - 2451545.0
        val g = fixAngle(357.529 + 0.98560028 * d)
        val q = fixAngle(280.459 + 0.98564736 * d)
        val l = fixAngle(q + 1.915 * dsin(g) + 0.020 * dsin(2 * g))
        val e = 23.439 - 0.00000036 * d
        val ra = fixHour(darctan2(dcos(e) * dsin(l), dcos(l)) / 15)
        val eqt = q / 15 - ra
        val decl = darcsin(dsin(e) * dsin(l))
        return decl to eqt
    }

    fun compute(
        lat: Double, lng: Double, cal: Calendar,
        method: Method, hanafi: Boolean,
    ): DayTimes {
        val y = cal.get(Calendar.YEAR); val m = cal.get(Calendar.MONTH) + 1; val d = cal.get(Calendar.DAY_OF_MONTH)
        val noonCal = (cal.clone() as Calendar).apply { set(Calendar.HOUR_OF_DAY, 12); set(Calendar.MINUTE, 0) }
        val tz = TimeZone.getDefault().getOffset(noonCal.timeInMillis) / 3_600_000.0
        val jDate = julian(y, m, d) - lng / (15 * 24.0)

        fun midDay(t: Double): Double = fixHour(12 - sunPosition(jDate + t).second)
        fun sunAngleTime(angle: Double, t: Double, ccw: Boolean): Double {
            val decl = sunPosition(jDate + t).first
            val noon = midDay(t)
            val tt = darccos((-dsin(angle) - dsin(decl) * dsin(lat)) / (dcos(decl) * dcos(lat))) / 15
            return noon + if (ccw) -tt else tt
        }
        fun asrTime(factor: Double, t: Double): Double {
            val decl = sunPosition(jDate + t).first
            val angle = -darccot(factor + dtan(abs(lat - decl)))
            return sunAngleTime(angle, t, false)
        }

        // two iterations for precision
        var fajr = 5.0; var sunrise = 6.0; var dhuhr = 12.0; var asr = 13.0; var sunset = 18.0; var isha = 18.0
        repeat(2) {
            if (fajr.isNaN()) fajr = 5.0
            if (isha.isNaN()) isha = 19.0
            val f = sunAngleTime(method.fajrAngle, fajr / 24, true)
            val sr = sunAngleTime(0.833, sunrise / 24, true)
            val dh = midDay(dhuhr / 24)
            val a = asrTime(if (hanafi) 2.0 else 1.0, asr / 24)
            val ss = sunAngleTime(0.833, sunset / 24, false)
            val i = method.ishaAngle?.let { sunAngleTime(it, isha / 24, false) } ?: Double.NaN
            fajr = f; sunrise = sr; dhuhr = dh; asr = a; sunset = ss; isha = i
        }

        // Method-specific Isha in minutes
        method.ishaMinutes?.let { isha = sunset + it / 60.0 }

        // High-latitude adjustment (angle-based rule) — needed in Poland in summer
        val night = fixHour(sunrise - sunset)
        val fajrPortion = method.fajrAngle / 60.0 * night
        if (fajr.isNaN() || fixHour(sunrise - fajr) > fajrPortion) fajr = sunrise - fajrPortion
        if (method.ishaAngle != null) {
            val ishaPortion = method.ishaAngle / 60.0 * night
            if (isha.isNaN() || fixHour(isha - sunset) > ishaPortion) isha = sunset + ishaPortion
        }

        val shift = tz - lng / 15
        dhuhr += 1.0 / 60 // safety minute after zenith
        return DayTimes(
            fixHour(fajr + shift), fixHour(sunrise + shift), fixHour(dhuhr + shift),
            fixHour(asr + shift), fixHour(sunset + shift), fixHour(isha + shift),
        )
    }

    fun format(h: Double): String {
        if (h.isNaN()) return "--:--"
        val total = ((h * 60) + 0.5).toInt()
        return "%02d:%02d".format((total / 60) % 24, total % 60)
    }
}
