package pl.salah.watch

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.os.CancellationSignal
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.concurrent.Executors

data class City(val name: String, val lat: Double, val lng: Double)

val CITIES = listOf(
    City("Mysłowice", 50.2081, 19.1666),
    City("Katowice", 50.2649, 19.0238),
    City("Kraków", 50.0647, 19.9450),
    City("Warszawa", 52.2297, 21.0122),
    City("Wrocław", 51.1079, 17.0385),
    City("Łódź", 51.7592, 19.4560),
    City("Poznań", 52.4064, 16.9252),
    City("Gdańsk", 54.3520, 18.6466),
    City("Szczecin", 53.4285, 14.5528),
    City("Lublin", 51.2465, 22.5684),
    City("Białystok", 53.1325, 23.1688),
)

/** Settings kept in SharedPreferences and exposed as Compose state. */
class Store(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("salah", Context.MODE_PRIVATE)

    var locationName by mutableStateOf(prefs.getString("locName", null))
        private set
    var lat by mutableStateOf(prefs.getFloat("lat", 0f).toDouble())
        private set
    var lng by mutableStateOf(prefs.getFloat("lng", 0f).toDouble())
        private set
    var method by mutableStateOf(Method.valueOf(prefs.getString("method", Method.MWL.name)!!))
        private set
    var hanafi by mutableStateOf(prefs.getBoolean("hanafi", false))
        private set
    var speed by mutableStateOf(prefs.getFloat("speed", 1f))
        private set
    var vibrate by mutableStateOf(prefs.getBoolean("vibrate", true))
        private set

    val hasLocation get() = locationName != null

    fun setLocation(name: String, la: Double, ln: Double) {
        locationName = name; lat = la; lng = ln
        prefs.edit().putString("locName", name).putFloat("lat", la.toFloat()).putFloat("lng", ln.toFloat()).apply()
    }
    fun cycleMethod() {
        method = Method.entries[(method.ordinal + 1) % Method.entries.size]
        prefs.edit().putString("method", method.name).apply()
    }
    fun toggleHanafi() { hanafi = !hanafi; prefs.edit().putBoolean("hanafi", hanafi).apply() }
    fun toggleVibrate() { vibrate = !vibrate; prefs.edit().putBoolean("vibrate", vibrate).apply() }
    fun cycleSpeed() {
        val opts = listOf(0.75f, 1f, 1.5f, 2f)
        speed = opts[(opts.indexOf(speed) + 1).let { if (it <= 0 || it >= opts.size) 0 else it }]
        prefs.edit().putFloat("speed", speed).apply()
    }
}

/** One-shot location fix from the watch's own GPS (or network). Permission must already be granted. */
@SuppressLint("MissingPermission")
fun requestLocation(ctx: Context, onResult: (Location?) -> Unit) {
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, "fused")
        .filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }
    val last = providers.mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
        .maxByOrNull { it.time }
    if (last != null && System.currentTimeMillis() - last.time < 6 * 3600_000L) { onResult(last); return }
    val provider = providers.firstOrNull() ?: run { onResult(last); return }
    lm.getCurrentLocation(provider, CancellationSignal(), Executors.newSingleThreadExecutor()) { loc ->
        onResult(loc ?: last)
    }
}
